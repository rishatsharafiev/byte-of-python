def say_hello():
    # block belonging to the function
    print('hello world')
    # End of function

say_hello() # call the function
say_hello() # call the function again
