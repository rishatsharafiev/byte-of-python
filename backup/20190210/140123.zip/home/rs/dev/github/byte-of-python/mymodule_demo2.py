from mymodule import say_hi, __version__

say_hi()
print('Version', __version__)
