# A Byte of Python

### Run python code
```
$ python hello.py
```
